<header>
    <div id="headerwrapper">
	   <h1>Pasta is the Best!</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="location.php">Location</a></li>
            </ul>
        </nav>
    </div>
</header>