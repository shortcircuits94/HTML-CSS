<footer>
    <p>&copy;2017 Rebecca Scott</p>
</footer>